<?php

namespace App\Controller;

use App\Entity\Event;
use App\Entity\Tag;
use App\Repository\EventRepository;
use DateTime;
use DateTimeImmutable;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


class EventController extends AbstractController
{

    /**
     * @Route("/events/{id}", name="show_event", requirements={"id"="\d+"})
     */
    public function show(Event $event): Response
    {
        return $this->render('event/show.html.twig', ['event' => $event]);
    }

    /**
     * @Route("/events/create", name="create_event")
     */
    public function createEvent(): Response
    {
        // on crée une categorie
        $event = new Event();
        $event->setPicture('https://images.pexels.com/photos/251225/pexels-photo-251225.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260');
        $event->setTitle('À la découverte du Japon');
        $event->setDescription('À la découverte du Japon et de la culture du manga');
        $event1->setDescription('Au Japon les manga sont très présents. Les premier mangas sont apparus au début du 20ème siécle
        mais sont inspiraient des emakimono, rouleau narratif pain japonais qui datent de plusieurs siécle avant.');
        // la date de l'événement c'est dans 14 jours à 10h30
        $event->setEventDate((new DateTime('+14 days'))->setTime(10, 30));
        $event->setIsPublished(true); // on publie l'événement
        $event->setPublishedAt(new DateTimeImmutable());

        // on crée un deuxième événement qui ne sera pas publié pour l'instant
        $event2 = new Event();
        // on renseigne seulement le titre qui est obligatoire
        $event2->setTitle('categorie à venir, pas encore publique');

        // on ajoute quelques tags à l'événement
        $webTag = new Tag();
        $webTag->setLabel('web');
        $event->addTag($webTag);

        $codeTag = new Tag();
        $codeTag->setLabel('code');
        $event->addTag($codeTag);

        /* on récupère le gestionnaire d'entités qui va nous permettre
            d'enregistrer l'événement */
        $entityManager = $this->getDoctrine()->getEntityManager();

        /* on confie l'objet $event au gestionnaire d'entités,
            l'objet n'est pas encore enregistrer en base de données */
        $entityManager->persist($event);

        // on confie aussi l'objet $event2 au gestionnaire d'entités
        $entityManager->persist($event2);

        /* on exécute maintenant les 2 requêtes qui vont ajouter
            les objets $event et $event2 en base de données */
        $entityManager->flush();

        return new Response(
            "Les categorie {$event->getTitle()} et {$event2->getTitle()}
                ont bien été enregistrés."
        );
    }

    /**
     * @Route("/events/{id}/update", name="update_event")
     */
    public function update(
        Event $event,
        EntityManagerInterface $entityManager
    ): Response {
        // grâce au ParamConverter, nous avons automatiquement accès à l'objet $event
        $event->setTitle("Manga shojo");
        $event->setEventDate((new \DateTime('+14 days'))->setTime(15, 30));

        $entityManager->flush();

        return new Response("La categorie a bien été modifier.");
    }

    /**
     * @Route("/events/{id}/delete", name="delete_event")
     */
    public function delete(
        Event $event,
        EntityManagerInterface $entityManager
    ): Response {
        // grâce au ParamConverter, nous avons automatiquement accès à l'objet $event
        $entityManager->remove($event); // on utilise la method remove de l'entity manager
        $entityManager->flush();

        return new Response("La categorie {$event->getId()} à bien été supprimer.");
    }

    /**
     * @Route("/events/{category}", name="list_events")
     */
    public function list($category = null): Response
    {
        $htmlMessage = "<h1>Liste des categorie";
        if ($category) {
            $htmlMessage .= " ave le type: ${category}";
        }
        $htmlMessage .= "</h1>";

        return new Response($htmlMessage);
    }
}
