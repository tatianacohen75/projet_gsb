<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CaegoryController extends AbstractController
{
    #[Route('/caegory', name: 'app_caegory')]
    public function index(): Response
    {
        return $this->render('caegory/index.html.twig', [
            'controller_name' => 'CaegoryController',
        ]);
    }
}
