<?php

namespace App\DataFixtures;

use App\Entity\Event;
use App\Entity\Tag;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        // $product = new Product();
        // $manager->persist($product);
        $webTag = new Tag();
        $webTag->setLabel('web');

        $codeTag = new Tag();
        $codeTag->setLabel('code');

        $apiTag = new Tag();
        $apiTag->setLabel('api');

        $designTag = new Tag();
        $designTag->setLabel('api');

        $event1 = new Event();
        $event1->setPicture('https://www.journaldugeek.com/content/uploads/2018/09/tokyo.jpg');
        $event1->setTitle('À la découverte du Japon et de la culture du manga');
        $event1->setDescription('Au Japon les manga sont très présents. Les premier mangas sont apparus au début du 20ème siécle
        mais sont inspiraient des emakimono, rouleau narratif pain japonais qui datent de plusieurs siécle avant.');
        // la date de l'événement c'est dans 14 jours à 10h30
        $event1->setEventDate((new \DateTime('+14 days'))->setTime(10, 30));
        $event1->setIsPublished(true);
        $event1->setPublishedAt(new \DateTimeImmutable());
        $event1->addTag($webTag);
        $event1->addTag($codeTag);
        $manager->persist($event1);

        $event2 = new Event();
        $event2->setTitle('Manga shonen');
        $event2->setPicture('https://img.hebus.com/hebus_2012/01/31/preview/1328029624_44.jpg');
        $event2->setDescription('Le shonen et un genre de manga destiné principalement à un public masculin.
        Parmis les shonens les plus connus il y a :
        -DBZ
        -Naruto
        -Fairy Tail
        -One Piece');
        // la date de l'événement c'est dans 10 jours à 10h00
        $event2->setEventDate((new \DateTime('+10 days'))->setTime(10, 0));
        $event2->setIsPublished(true);
        $event2->setPublishedAt(new \DateTimeImmutable());
        $event2->addTag($webTag);
        $event2->addTag($codeTag);
        $event2->addTag($apiTag);
        $manager->persist($event2);

        $event3 = new Event();
        $event3->setTitle('Introduction les differents genre du manga');
        $event3->setPicture('https://upload.wikimedia.org/wikipedia/commons/6/62/MangaStoreJapan.jpg');
        $event3->setDescription('Il existe plusieurs genre de manga. Il y a les shojo, shonen, seinen, josei.
        Tous ses genre sont classé selon l age ou est destiné le manga.
        Par exemple les shonen sont pour les personnes entre 8 et 18 ans, les shojo entre 8 et 18 ans, les seinen pour les +18');
        // la date de l'événement c'est dans 14 jours à 16h00
        $event3->setEventDate((new \DateTime('+14 days'))->setTime(16, 0));
        $event3->setIsPublished(true);
        $event3->setPublishedAt(new \DateTimeImmutable());
        $event3->addTag($designTag);
        $manager->persist($event3);

        $event4 = new Event();
        $event4->setTitle('Manga shojo');
        $event4->setPicture('https://rosalys.files.wordpress.com/2018/02/mon-top5-shojo-manga-hiver-2018.jpg');
        $event4->setDescription('Le shojo est un genre de manga déstiné principalement à un public féminain.
        Parmis les shojos les plus connus il y a :
        -Nana
        -Seilor Moon
        -Sakura chasseuse de carte
        -Fruits Basket');
        // la date de l'événement c'est dans 5 jours à 10h00
        $event4->setEventDate((new \DateTime('+5 days'))->setTime(10, 0));
        $event4->setIsPublished(true);
        $event4->setPublishedAt(new \DateTimeImmutable());
        $event4->addTag($apiTag);
        $event4->addTag($webTag);
        $manager->persist($event4);

        $event5 = new Event();
        $event5->setTitle('Manga seinen');
        $event5->setPicture('https://www.francenetinfos.com/wp-content/uploads/2019/01/atrail.jpg');
        $event5->setDescription('Lorem ipsum dolor sit amet consectetur
            adipisicing, elit. Libero tenetur beatae repellendus possimus magni
            quae! Impedit soluta sit iusto amet unde repudiandae fugit
            perspiciatis, deleniti quod placeat.');
        // la date de l'événement c'est dans 5 jours à 10h00
        $event5->setEventDate((new \DateTime('+5 days'))->setTime(10, 0));
        $event5->setIsPublished(true);
        $event5->setPublishedAt(new \DateTimeImmutable());
        $event5->addTag($apiTag);
        $event5->addTag($webTag);
        $manager->persist($event4);

        $event6 = new Event();
        $event6->setTitle('Événement à venir, pas encore publique');


        $manager->flush();
    }
}
